package org.example;


import java.util.Stack;

public class LIFOBuffer {
    private Stack<String> stack;

    public LIFOBuffer() {
        stack = new Stack<>();
    }

    public void push(String text) {
        stack.push(text);
    }

    public String pop() {
        return stack.pop();
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }
}

