package org.example;

public class Trabalho3 {

    public static void main(String[] args) {

        FIFOBuffer fifoBuffer = new FIFOBuffer(10);
        LIFOBuffer lifoBuffer = new LIFOBuffer();

        // Enqueue strings to create a line of text in the FIFO buffer
        fifoBuffer.fila("teste");
        fifoBuffer.fila("do");
        fifoBuffer.fila("programa");
        fifoBuffer.fila("!");

        // Push strings onto the LIFO buffer
        lifoBuffer.push("teste");
        lifoBuffer.push("do");
        lifoBuffer.push("programa");
        lifoBuffer.push("!");

        // Dequeue strings from the FIFO buffer to retrieve and display the line of text
        while (!fifoBuffer.vazio()) {
            String frase = fifoBuffer.imprimirFila();
            System.out.print(frase + " ");
        }

        System.out.println();

        // Pop strings from the LIFO buffer to retrieve and display the line of text
        while (!lifoBuffer.isEmpty()) {
            String frase = lifoBuffer.pop();
            System.out.print(frase + " ");
        }
    }
}
